# 关键业务逻辑说明

## 1. 登录与权限

1. 注册时用 NFKC 标准化用户名，并生成 `usernameKey`。
2. 密码通过 Werkzeug scrypt 生成不可逆哈希。
3. 登录成功后生成 32 字节随机令牌。
4. 浏览器只保存原始令牌，MongoDB 只保存 SHA-256 哈希和过期时间。
5. 每次受保护请求都查询有效会话。
6. 问卷管理接口同时按 `_id` 和 `ownerId` 查询，其他用户只能得到 `404`。

## 2. 问卷状态机

```text
创建
  │
  ▼
draft ──发布──> published ──关闭/截止──> closed
  ▲                 │                      │
  └────不能改题─────┘                      │
                                           │
                        无回答时可改题并重新发布
```

规则：

- `draft`：可改题目，链接不能填写。
- `published`：链接可填写，不能改题目。
- `closed`：停止填写。
- 截止时间到达后，公开查询会惰性把状态改为 `closed`；提交接口也会独立检查截止时间。
- 已发布问卷若要修改题目，必须先关闭；若已有回答，关闭后仍不能改题。

## 3. 题目模型

所有逻辑由通用字段驱动，不为某一份具体问卷写死：

```text
题目
├─ id
├─ type
├─ title
├─ required
├─ options[]
├─ validation{}
└─ jumps[]
```

跳转规则：

```text
单选题
  condition = { operator: "option_is", optionId }

多选题
  condition = { operator: "contains", optionId }

数字题
  condition = {
    operator: "eq" | "neq" | "gt" | "gte" | "lt" | "lte" | "between",
    value
  }
```

## 4. 服务端答案校验

服务端对每种题型执行：

| 题型 | 校验 |
| --- | --- |
| 单选 | 值必须是一个属于当前题目的选项 ID |
| 多选 | 数组、无重复、所有 ID 合法、满足最少/最多选择数 |
| 文本 | 类型正确，去除首尾空白后检查最少/最多字符数 |
| 数字 | 有限数值、整数规则、最小值/最大值 |
| 必答 | 到达该题且答案为空时拒绝 |

浏览器也会执行同类校验，目的是及时提示；最终结果以服务端为准。

## 5. 跳转遍历算法

服务端不直接接受客户端给出的“下一题”，而是根据保存的问卷配置重新计算路径。

```text
current = 第一题
result = []

while current 存在:
    value = 当前题目的答案

    if value 为空:
        if current.required:
            reject
        else:
            current = 下一题
            continue

    校验 value
    将答案加入 result

    rule = 当前题目 jumps 中第一条命中的规则
    if rule:
        current = rule.targetQuestionId
    else:
        current = 下一题

if 请求中存在未到达题目的答案:
    reject
```

行为细节：

- 规则顺序有意义，命中第一条即停止。
- 没命中规则时进入下一题。
- 被跳过的必答题不需要回答。
- 客户端提交未到达题目的答案会被拒绝，防止隐藏分支数据污染统计。
- 跳转目标必须是后面的题目，从数据层消除环路。

## 6. 提交完整性

### 重复填写

- 问卷允许重复时，同一账号可以产生多条 `submissions`。
- 问卷不允许重复时，按 `surveyId + participantKey` 检查已有文档。
- 数据库部分唯一索引处理并发双击或两个并发请求。

### 幂等重试

- 浏览器提交前生成 `idempotencyKey`。
- 相同用户对同一问卷重复发送同一个键时，返回原提交 ID。
- 避免网络中断后用户重试造成两条回答。

### 匿名

- `allowAnonymous=true` 时，回答文档不保存用户 `_id`。
- 去重仍需要一个技术键，因此保存加盐 HMAC，而不是用户名。
- 统计接口不返回填写者信息。

## 7. 统计数据流

```javascript
submissions.aggregate([
  { $match: { surveyId } },
  {
    $facet: {
      total: [{ $count: "count" }],
      answers: [
        { $unwind: "$answers" },
        {
          $group: {
            _id: "$answers.questionId",
            values: { $push: "$answers.value" }
          }
        }
      ]
    }
  }
])
```

逐题计算：

- 单选：按选项 ID 计数。
- 多选：先展开所选 ID 数组，再逐项计数。
- 文本：返回全部回答文本。
- 数字：计算平均值、最小值、最大值，并返回全部数值。

跳转跳过的题目没有对应答案文档，因此该题回答人数自然不增加。

## 8. 并发与一致性

- 用户名使用唯一索引防止并发重复注册。
- URL `slug` 使用唯一索引。
- 参与者去重与幂等键使用部分唯一索引。
- 题目保存只允许在未发布、无回答的草稿状态，因此无需事务即可安全替换。
- 发布、关闭、截止时间都同时在路由层和数据库条件更新中检查，减少状态竞态。
